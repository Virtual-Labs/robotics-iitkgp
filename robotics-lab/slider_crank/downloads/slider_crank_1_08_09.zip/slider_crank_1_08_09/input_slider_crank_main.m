function input_slider_crank
global c;global r;global l;global e;global err;
err=0;

l=10;r=5;e=0;
fig_1=figure('name','Indian Institute of Technology, Kharagpur - Virtual Laboratory','menubar','none','numbertitle',...
    'off','color',[    0.4898    0.4456    0.6463],'units',...
    'normalized','position',[0,0,1,1]);

subplot('Position',[0.3 0.45 0.4 0.4]);
      rgb = imread('slider_crank.jpg');
      image(rgb);
   axis off   

uicontrol('sty','text','un','n','pos',[.275 .87 .45 .1],'visible','on','string','Slider crank Mechanism',...
    'fontsize',20,'BackgroundColor',[0.4898    0.4456    0.6463]);

K_p2 = uipanel(fig_1,...
    'units','pixels',...
    'Position',[430 100 100 200],...
    'Title','Input lengths','FontSize',11,'BackgroundColor',[0.4898    0.4456    0.6463]);

uicontrol('sty','text','un','n','pos',[.28 .3 .05 .03],'visible','on','string','Crank',...
    'fontsize',15,'BackgroundColor',[0.4898    0.4456    0.6463]);

uicontrol('sty','text','un','n','pos',[.28 .235 .05 .03],'visible','on','string','Slider',...
    'fontsize',15,'BackgroundColor',[0.4898    0.4456    0.6463]);

uicontrol('sty','text','un','n','pos',[.28 .175 .05 .03],'visible','on','string','Offset',...
    'fontsize',15,'BackgroundColor',[0.4898    0.4456    0.6463]);

LD=100;BT=120;HT=25;k1=10;

c1_edit = uicontrol(K_p2,'style','edit',...
    'String',0,...
    'callback',@c1_edit_button_press,...
    'Position',[LD-75 BT 50 HT]); % L, B, W, H


s1_edit = uicontrol(K_p2,'style','edit',...
    'String',0,...
    'callback',@s1_edit_button_press,...
    'Position',[LD-75 BT-45 50 HT]); % L, B, W, H

o1_edit = uicontrol(K_p2,'style','edit',...
    'String',0,...
    'callback',@o1_edit_button_press,...
    'Position',[LD-75 BT-90 50 HT]); % L, B, W, H


uicontrol('style','push','units','normalized','position',[.5 .3 .1 .08],'string','Help','fontsize',14,'callback',@help)

uicontrol('style','push','units','normalized','position',[.5 .15 .1 .08],'string','Simulation', 'fontsize',14,'callback',@slider)

uicontrol('sty','text','un','n','pos',[.62 .02 .35 .05],'visible','on','string','Note: All lengths and coordinates are in mm',...
    'fontsize',11,'BackgroundColor',[0.4898    0.4456    0.6463]);

    function c1_edit_button_press(h,dummy)
        
        r = str2double(get(h,'string'))
         if isnan(r)
        errordlg('enter a numeric value') 
         end
     end

    function s1_edit_button_press(h,dummy)
        
        l = str2double(get(h,'string'))
         if isnan(l)
        errordlg('enter a numeric value') 
         end        
    end
    
    function o1_edit_button_press(h,dummy)
        
        e = str2double(get(h,'string'))
         if isnan(e)
        errordlg('enter a numeric value') 
         end
    end

        function check(varargin)
            
              
             if l>=(r+ abs(e)) | (l+abs(e))<r 
              err=0;
             else
              err=1;  
             end
             if (l==(r+abs(e)) && e<0)
             err=1;
             end
             if err==1
                   errordlg('Linkage is non Grashofian','Input Error')
             end
    end   

    function slider(varargin)
        check
        if err==0
        slider_crank(r,l,e)
        end
    end 
%     clc
  end
