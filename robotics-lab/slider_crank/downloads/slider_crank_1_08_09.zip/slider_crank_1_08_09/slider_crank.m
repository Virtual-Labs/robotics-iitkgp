function [] = slider_crank(s,l,o)

     fig_1=figure('name','Mechanism','menubar','none','numbertitle',...
    'off','color',[    0.4898    0.4456    0.6463],'units',...
    'normalized','position',[0,0,1,1]);

     uicontrol('style','push','units','normalized','position',[.45 .03 .06 .04],'string','Home','fontsize',11,'callback',@home)
     
    function home(varargin)
     close
    end 
        
        e=0;
        if l==s && o==0
        e=1;
        end 
    
        c=2*max(l,s);
    
       if l>=(s+ abs(o)) 
    disp('case1');
        x1=0;y1=0;
        x2=s;y2=0;
        theta1=0;
        theta2=asin((s*sin(theta1)-o)/l);
        x3=x2+l*cos(theta2);y3=o;

        x4=x3+c/8;
        x5=x3-c/8;

        X1=[x1 x2 ];
        Y1=[y1 y2 ];
        X2=[x2 x3 ];
        Y2=[y2 y3 ];
        X3=[x5 x4];
        Y3=[y3 y3];

        subplot('Position',[0.05 0.57 0.38 0.38]);
        p1=plot(X1,Y1,'bo-','EraseMode','xor','LineWidth',8);
        hold on
        p2=plot(X2,Y2,'go-','EraseMode','xor','LineWidth',8);
        hold on
        p3=plot(X3,Y3,'r','EraseMode','xor','LineWidth',16);
        
        title('Simulation','fontsize',14)

        
        scale=2.1*max(s,l);
        grid
        axis([-scale scale -scale scale])
        axis equal   
        
         
            if theta2<0
             theta2=theta2+2*pi;   
            end

        subplot('Position',[0.05 0.07 0.38 0.38]);
        theta1
        theta2
        t1=plot(-1,-1,'r.','EraseMode','none'); % Plot of theta1 vs theta2
        xlabel('Theta1(degrees)','fontsize',11)
        ylabel('Theta2(degrees)','fontsize',11)
        title('Theta2(driven) vs Theta1(driver)','fontsize',13)

        scale=380;
        grid
        axis([0 2*scale 0 scale])
        
        
             tic
             StartTime=toc;
             
              subplot('Position',[0.54 0.57 0.38 0.38]);
              t2=plot(-1,theta1*180/pi,'r.','EraseMode','none'); %plot of theta1 vs time
              xlabel('Time(seconds)','fontsize',11)
              ylabel('Theta1(degrees)','fontsize',11)
              title('Theta1 vs Time','fontsize',13)

               grid
               axis([0 30 0 800])

              subplot('Position',[0.54 0.07 0.38 0.38]);
              t3=plot(-1,theta2*180/pi,'r.','EraseMode','none'); %plot of theta2 vs time
              xlabel('Time(seconds)','fontsize',11)
              ylabel('Theta2(degrees)','fontsize',11)
              title('Theta2 vs Time','fontsize',13)


               grid
               axis([0 30 0 400])
        ZeroTime=0;

        for theta1=0:0.04:4*pi
      
          x1=0;y1=0;
          x2=s*cos(theta1);y2=s*sin(theta1);
          theta2=asin((s*sin(theta1)-o)/l);
          sprintf('\n%d,  %d',theta1,theta2)
       
           if ((theta1<3/2*pi && theta1>pi/2) && e==1) |  ( l==(s+ abs(o)) && theta1>=3*pi/2 && e==0)  |((theta1<6*pi && theta1>5*pi/2) && e==1)
            x3=x2-l*cos(theta2);y3=o;
           else
             x3=x2+l*cos(theta2);y3=o;   
           end
           
           if theta1>=7*pi/2
            x3=x2+l*cos(theta2);y3=o; 
           end
           
            x4=x3+c/8;
            x5=x3-c/8;
            X1=[x1 x2 ];
            Y1=[y1 y2 ];
            X2=[x2 x3 ];
            Y2=[y2 y3 ];
            X3=[x5 x4];
            Y3=[y3 y3];
 
%             set(t,'XData',x3,'YData',y3)
            set(p1,'XData',X1,'YData',Y1)
            set(p2,'XData',X2,'YData',Y2)
            set(p3,'XData',X3,'YData',Y3)
            
            if theta2<0
             theta2=theta2+2*pi;   
            end
            
%             subplot('Position',[0.05 0.07 0.38 0.38]);
            set(t1,'XData',theta1*180/pi,'YData',theta2*180/pi)
           
            EndTime=toc;
            
             
            if theta1==0
                ZeroTime=toc;
            end
            
          
          subplot('Position',[0.54 0.57 0.38 0.38]);
          set(t2,'XData',EndTime-ZeroTime,'YData',theta1*180/pi) 
          
          subplot('Position',[0.54 0.07 0.38 0.38]);
          set(t3,'XData',EndTime-ZeroTime,'YData',theta2*180/pi)
          pause(0.15-(EndTime-StartTime))
          
          drawnow
          StartTime=EndTime;
        end
      
     elseif (l+abs(o))<s  
             disp('case2');
           x1=0;y1=0;
           t1_int=asin((l+o)/s);
           x2=s*cos(t1_int);y2=s*sin(t1_int);
           x3=x2;y3=o;
           
            x4=x3+c/8;
            x5=x3-c/8;
           
            theta2=pi/2;
            theta1=asin((o+l*sin(theta2))/s);

            X1=[x1 x2 ];
            Y1=[y1 y2 ];
            X2=[x2 x3 ];
            Y2=[y2 y3 ];
            X3=[x5 x4];
            Y3=[y3 y3];

            subplot('Position',[0.05 0.57 0.38 0.38]);
            p1=plot(X1,Y1,'bo-','EraseMode','xor','LineWidth',8);
            hold on
            p2=plot(X2,Y2,'go-','EraseMode','xor','LineWidth',8);
            hold on
            p3=plot(X3,Y3,'r','EraseMode','xor','LineWidth',16);

            title('Simulation','fontsize',14)
            


            scale=2.1*max(s,l);
            grid
            axis([-scale scale -scale scale])
            axis equal   
            
            
            if theta1<0
             theta1=theta1+2*pi;   
            end
           
            subplot('Position',[0.05 0.07 0.38 0.38]);
            t=plot(theta2*180/pi,theta1*180/pi,'r.','EraseMode','none'); % Plots the coupler point in red
            xlabel('Theta2(degrees)','fontsize',11)
            ylabel('Theta1(degrees)','fontsize',11)
            title('Theta1(driven) vs Theta2(driver)','fontsize',13)

            scale=380;
            grid
            axis([90 500 0 scale])


             tic
             StartTime=toc;
             
              subplot('Position',[0.54 0.57 0.38 0.38]);
              t2=plot(-1,theta1*180/pi,'r.','EraseMode','none'); 
              xlabel('Time(seconds)','fontsize',11)
              ylabel('Theta1(degrees)','fontsize',11)
              title('Theta1 vs Time','fontsize',13)

               grid
               axis([0 20 0 400])

              subplot('Position',[0.54 0.07 0.38 0.38]);
              t3=plot(-1,theta2*180/pi,'r.','EraseMode','none'); 
              xlabel('Time(seconds)','fontsize',11)
              ylabel('Theta2(degrees)','fontsize',11)
              title('Theta2 vs Time','fontsize',13)


               grid
               axis([0 20 90 600])
        
          ZeroTime=0;     

         for theta2=pi/2:0.04:5/2*pi
             
            theta1=asin((o+l*sin(theta2))/s);
            
           x1=0;y1=0;
           x2=s*cos(theta1);y2=s*sin(theta1);
           
           if (l+abs(o))<=s && theta2>5*pi/2
            x3=x2-l*cos(theta2);y3=o; 
           else    
            x3=x2+l*cos(theta2);y3=o;
           end
           
            x4=x3+c/8;
            x5=x3-c/8;

            X1=[x1 x2 ];
            Y1=[y1 y2 ];
            X2=[x2 x3 ];
            Y2=[y2 y3 ];
            X3=[x5 x4];
            Y3=[y3 y3];
           
%             set(t,'XData',x3,'YData',y3)
            set(p1,'XData',X1,'YData',Y1)
            set(p2,'XData',X2,'YData',Y2)
            set(p3,'XData',X3,'YData',Y3)
            
            if theta1<0
             theta1=theta1+2*pi;   
            end
            
            subplot('Position',[0.05 0.07 0.38 0.38]);
            set(t,'XData',theta2*180/pi,'YData',theta1*180/pi)
              
            EndTime=toc;
            pause(0.15-(EndTime-StartTime))
           
          
             if theta2==pi/2
                ZeroTime=toc;
             end
            
            subplot('Position',[0.54 0.57 0.38 0.38]);
            set(t2,'XData',EndTime-ZeroTime,'YData',theta1*180/pi) 

            subplot('Position',[0.54 0.07 0.38 0.38]);
            set(t3,'XData',EndTime-ZeroTime,'YData',theta2*180/pi)
            
            StartTime=EndTime;
             drawnow

         end
       end  
%          clc
   end
     